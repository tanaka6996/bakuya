# HatCloud - discontinued

HatCloud build in Ruby. It makes bypass in CloudFlare for discover real IP.
This can be useful if you need test your server and website. Testing your protection against Ddos (Denial of Service) or Dos.
CloudFlare is services and distributed domain name server services, sitting between the visitor and the Cloudflare user's hosting provider, acting as a reverse proxy for websites. 
Your network protects, speeds up and improves availability for a website or the mobile application with a DNS change. 

Version: 1.0

<em>Use:</em>
<strong>ruby hatcloud.rb -h or --help </strong><br />
<strong>ruby hatcloud.rb -b your site </strong> <br />
or<br />
<strong>ruby hatcloud.rb --byp your site </strong><br />



HatCloud, um simples script criado em Ruby para realizar um bypass no CloudFlare, descobrindo seu endereço de IP real. 
Isto pode ser útil para você testar o seu servidor e seu site. Testando sua proteção contra Ddos ou Dos (negação de serviço) .

CloudFlare fornece uma rede de entrega de conteúdo e serviços distribuídos de DNS, sendo o intermediário entre o visitante e o 
provedor de hospedagem do usuário da Cloudflare, atuando como um proxy reverso para website. A sua rede protege, acelera e melhora a 
disponibilidade de um website ou aplicação móvel com uma mudança no DNS. 

Versão: 1.0

<em>Uso: </em>
<strong>ruby hatcloud.rb -b seu site </strong><br />
ou<br />
<strong>ruby hatcloud.rb --byp seu site</strong><br />

#Screenshot
<img src="https://i.imgur.com/iB2e0AU.png"> <br />

